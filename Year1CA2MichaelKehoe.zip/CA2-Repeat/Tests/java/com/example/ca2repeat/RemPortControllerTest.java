package com.example.ca2repeat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RemPortControllerTest {

    @Test
    void delPort() {
    }
}