package com.example.ca2repeat;

import javafx.event.ActionEvent;

import java.io.IOException;

public class MainMenuController {
    //Create sceneswaps
    public void swapAddConsole(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddConsoleController.fxml");
    }
    public void swapAddGame(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddGameController.fxml");
    }

    public void swapAddPort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("AddPortController.fxml");
    }

    public void swapViewConsole(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewConsoleController.fxml");
    }
    public void swapViewGame(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewGameController.fxml");
    }

    public void swapViewPort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("ViewPortController.fxml");
    }

    public void swapDelConsole(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("remConsoleController.fxml");
    }
    public void swapDelGame(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("remGameController.fxml");
    }

    public void swapDelPort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("remPortController.fxml");
    }

    public void swapEditConsole(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("editConsoleController.fxml");
    }

    public void swapEditGame(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("editGameController.fxml");
    }

    public void swapEditPort(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("editPortController.fxml");
    }

    public void swapSearchSystem(ActionEvent actionEvent) throws IOException{
        HelloApplication.changeScene("SearchSystemController.fxml");
    }

    public void swapSortSystem(ActionEvent actionEvent) throws IOException{
        HelloApplication.changeScene("SortSystemController.fxml");
    }
}