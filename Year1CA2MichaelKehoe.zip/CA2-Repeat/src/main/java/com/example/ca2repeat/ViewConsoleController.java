package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.io.IOException;

public class ViewConsoleController {
    public ListView viewConsoles;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> ctemp = Console.consoleList.head;
        while (ctemp != null) {
            viewConsoles.getItems().add(ctemp.getContents());
            ctemp = ctemp.next;
        }
    }
}
