package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddGameController {

    //Fields
    //name,manufacturer,description,media,image int year,price;
    public TextField gameName;
    public TextField gamePublisher;
    public TextField gameDesc;
    public TextField gameDev;
    public TextField gameCover;
    public TextField gameYear;
    public ChoiceBox<String> selectedConsole;

    //Creates game in consoleGames list
    public void CreateGame(ActionEvent actionEvent) {
        Game game1 = new Game(gameName.getText(), gamePublisher.getText(), gameDesc.getText(),
                gameDev.getText(), gameCover.getText(),
                Integer.parseInt(gameYear.getText()));
        FunkyList<Console>.FunkyNode<Console> temp = Console.consoleList.head;
        while (temp != null && !temp.getContents().getConsole().equals(selectedConsole.getValue()))
            temp = temp.next;
        if (temp != null)
            temp.getContents().consoleGames.addElement(game1);
    }

    //Fills selectedConsole TextBox
public void initialize(){
    FunkyList<Console>.FunkyNode<Console> ptemp = Console.consoleList.head;
        while (ptemp != null) {
            selectedConsole.getItems().add(ptemp.getContents().getConsole());
        ptemp = ptemp.next;
    }
}
    //Returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

