package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.io.IOException;

public class ViewGameController {
    //Fields

    //This and all other view[List] classes display a window that gets filled by initialise, allowing the user to view the corresponding list
    public ListView viewGames;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> ctemp=Console.consoleList.head;
        while(ctemp!=null) {
            FunkyList<Game>.FunkyNode<Game> temp= ctemp.getContents().consoleGames.head;
            while(temp!=null) {
                viewGames.getItems().add(temp.getContents());
                temp = temp.next;
            }
            ctemp=ctemp.next;
        }
    }
}
