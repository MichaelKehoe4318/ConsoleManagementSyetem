package com.example.ca2repeat;

public class Game {

        public FunkyList<Port> gamePorts = new FunkyList<>();

        //Fields
        String title, publisher, description, developer, cover;
        int year;
        public static Game head;

        //Getters
    public String getTitle() {
        return title;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getDescription() {return description;}

    public String getDeveloper() {
        return developer;
    }

    public String getCover() {
        return cover;
    }

    public int getYear() {
        return year;
    }

    public FunkyList<Port> getGamePorts() {
        return gamePorts;
    }

    //Setters
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public void setYear(int year) {
        this.year = year;
    }
    //title, publisher, description, developer, origConsole, cover
    public Game(String title, String desc, String pub, String dev, String gameCover, int relYear){
        this.title=title;
        description=desc;
        publisher=pub;
        developer=dev;
        cover=gameCover;
    }

    public static Game getGameByName(String value) {
        FunkyList<Console>.FunkyNode<Console> ptemp=Console.consoleList.head;
        while(ptemp!=null) {
            FunkyList<Game>.FunkyNode<Game> temp = ptemp.getContents().consoleGames.head;
            while (temp != null && !temp.getContents().getTitle().equals(value))
                temp = temp.next;
            if (temp != null)
                return temp.getContents();
            ptemp=ptemp.next;
        }
        return null;
    }

    public String toString(){return "Title: "+title+" Description: "+description+" Publisher: "+publisher+" Developer: "+developer+" Original Console: "+" Game Cover:"+cover;
    }
}

