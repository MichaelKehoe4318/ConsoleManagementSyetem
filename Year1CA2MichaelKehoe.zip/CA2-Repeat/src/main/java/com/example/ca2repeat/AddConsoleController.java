package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddConsoleController {

    //Fields
    //name,manufacturer,description,media,image int year,price;
    public TextField consoleName;
    public TextField consoleManufacturer;
    public TextField consoleDesc;
    public TextField consoleMedia;
    public TextField consoleImgURL;
    public TextField consoleYear;
    public TextField consolePrice;

    //Creates port within the list of ports
    public void CreateConsole(ActionEvent actionEvent) {
        Console console1 = new Console(consoleName.getText(), consoleManufacturer.getText(), consoleDesc.getText(),
                consoleMedia.getText(), consoleImgURL.getText(), Integer.parseInt(consoleYear.getText()),
                Integer.parseInt(consolePrice.getText()));
        Console.consoleList.addElement(console1);
        HelloApplication.showConsoles();
    }

    //Returns user to main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
