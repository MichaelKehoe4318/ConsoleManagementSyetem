package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

import static com.example.ca2repeat.Console.consoleList;

public class RemConsoleController {

    public ChoiceBox<Console> selectedDelConsole;

    public void delConsole(ActionEvent actionEvent) {
        Console selectedConsole = selectedDelConsole.getValue();

        if (selectedConsole != null) {
            consoleList.remove(selectedConsole);
            System.out.println("Console '" + selectedConsole.getConsole() + "' deleted");
            selectedDelConsole.getItems().remove(selectedConsole);
        } else {
            System.out.println("No console selected");
        }
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> temp = consoleList.head;
        while (temp != null) {
            selectedDelConsole.getItems().add(temp.getContents());
            temp = temp.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
