package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SortSystemController {

    public ListView<String> sortDisplay;
    public Button sortButton;
    public ChoiceBox<String> listToSort;

    // Hash maps for fast access
    private final HashMap<String, Console> consoleMap = new HashMap<>();
    private final HashMap<String, Game> gameMap = new HashMap<>();
    private final HashMap<String, Port> portMap = new HashMap<>();

    public void initialize() {
        listToSort.getItems().addAll("Consoles", "Games", "Ports");
        populateHashMaps(); // Populate hash maps on initialization
    }

    // Populate hash maps
    private void populateHashMaps() {
        // Clear existing hash maps to avoid stale data
        consoleMap.clear();
        gameMap.clear();
        portMap.clear();

        // Populate Console hash map
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
            Console console = consoleNode.getContents();
            consoleMap.put(console.getConsole(), console);

            // Populate Game and Port hash maps
            FunkyList<Game>.FunkyNode<Game> gameNode = console.getConsoleGames().head;
            while (gameNode != null) {
                Game game = gameNode.getContents();
                gameMap.put(game.getTitle(), game);
            }
            FunkyList<Port>.FunkyNode<Port> portNode = console.getConsolePorts().head;
            while (portNode != null) {
                Port port = portNode.getContents();
                portMap.put(port.getPortName(), port);
                portNode = portNode.next;
            }
            consoleNode = consoleNode.next;
        }
    }

    // Sorts the list alphabetically
    public void sortAll(ActionEvent actionEvent) {
        String selectedList = listToSort.getValue();

        if (selectedList == null) {
            return;
        }

        List<String> sortedList = new ArrayList<>();
        switch (selectedList) {
            case "Consoles" -> sortedList.addAll(consoleMap.keySet());
            case "Games" -> sortedList.addAll(gameMap.keySet());
            case "Ports" -> sortedList.addAll(portMap.keySet());
            default -> sortedList = new ArrayList<>();
        }

        // Sort list
        Collections.sort(sortedList);

        // Display list in the ListView
        sortDisplay.getItems().setAll(sortedList);
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

