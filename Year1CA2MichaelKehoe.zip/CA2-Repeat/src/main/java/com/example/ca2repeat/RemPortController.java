package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

public class RemPortController {

    // Fields
    public ChoiceBox<Port> selectedDelPort;
    public ChoiceBox<Console> selectedConsole;

    public void delPort(ActionEvent actionEvent) {
        Port selectedPort = selectedDelPort.getValue();

        if (selectedPort != null) {
            Console selectedConsole = this.selectedConsole.getValue();

            if (selectedConsole != null) {
                FunkyList<Port> consolePorts = selectedConsole.getConsolePorts();

                if (consolePorts != null) {
                    consolePorts.remove(selectedPort);
                    System.out.println("Port '" + selectedPort.getPortName() + "' deleted");

                    selectedDelPort.getItems().remove(selectedPort);
                } else {
                    System.out.println("No ports found");
                }
            } else {
                System.out.println("No console selected");
            }
        } else {
            System.out.println("No port selected");
        }
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;

        while (consoleNode != null) {
            selectedConsole.getItems().add(consoleNode.getContents());

            FunkyList<Port>.FunkyNode<Port> portNode = consoleNode.getContents().getConsolePorts().head;

            while (portNode != null) {
                selectedDelPort.getItems().add(portNode.getContents());
                portNode = portNode.next;
            }

            consoleNode = consoleNode.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        // Change the scene to the Main Menu
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
