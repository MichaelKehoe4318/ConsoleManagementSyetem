package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class EditPortController {

    // Fields for editing port details
    public ChoiceBox<String> portChoiceBox;
    public TextField portName;
    public TextField portDev;
    public TextField portCover;
    public TextField portRelease;

    // Initialize the controller, populate the ChoiceBox with port names
    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
                FunkyList<Port>.FunkyNode<Port> portNode = consoleNode.getContents().getConsolePorts().head;
                while (portNode != null) {
                    portChoiceBox.getItems().add(portNode.getContents().getPortName());
                    portNode = portNode.next;
                }
            consoleNode = consoleNode.next;
            }
        }


    // Load the selected port's data into the text fields for editing
    public void loadPortData(ActionEvent actionEvent) {
        Port selectedPort = Port.getPortByName(portChoiceBox.getValue());
        if (selectedPort != null) {
            portName.setText(selectedPort.getPortName());
            portDev.setText(selectedPort.getPortDev());
            portCover.setText(selectedPort.getPortCover());
            portRelease.setText(String.valueOf(selectedPort.getPortRelease()));
        }
    }

    // Save changes made to the port
    public void savePortChanges(ActionEvent actionEvent) {
        Port selectedPort = Port.getPortByName(portChoiceBox.getValue());
        if (selectedPort != null) {
            // Update port attributes based on user input
            selectedPort.setPortName(portName.getText());
            selectedPort.setPortDev(portDev.getText());
            selectedPort.setPortCover(portCover.getText());
            selectedPort.setPortRelease(Integer.parseInt(portRelease.getText()));

            // Notify the user that changes have been saved
            System.out.println("Port " + selectedPort.getPortName() + " updated successfully!");
        }
    }

    // Returns the user to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
