package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class EditGameController {

    // Fields for editing game details
    public ChoiceBox<String> gameChoiceBox;
    public TextField gameTitle;
    public TextField gamePublisher;
    public TextField gameDesc;
    public TextField gameDev;
    public TextField gameYear;
    public TextField gameCover;

    // Fill ChoiceBox with Games
    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
            FunkyList<Game>.FunkyNode<Game> gameNode = consoleNode.getContents().getConsoleGames().head;
            while (gameNode != null) {
                gameChoiceBox.getItems().add(gameNode.getContents().getTitle());
                gameNode = gameNode.next;
            }
            consoleNode = consoleNode.next;
        }
    }

    // Load game data into the fields
    public void loadGameData(ActionEvent actionEvent) {
        Game selectedGame = Game.getGameByName(gameChoiceBox.getValue());
        if (selectedGame != null) {
            gameTitle.setText(selectedGame.getTitle());
            gamePublisher.setText(selectedGame.getPublisher());
            gameDesc.setText(selectedGame.getDescription());
            gameDev.setText(selectedGame.getDeveloper());
            gameYear.setText(String.valueOf(selectedGame.getYear()));
            gameCover.setText(selectedGame.getCover());
        }
    }

    // Save changes made to the game
    public void saveGameChanges(ActionEvent actionEvent) {
        Game selectedGame = Game.getGameByName(gameChoiceBox.getValue());
        if (selectedGame != null) {
            // Update game with inputs
            selectedGame.setTitle(gameTitle.getText());
            selectedGame.setPublisher(gamePublisher.getText());
            selectedGame.setDescription(gameDesc.getText());
            selectedGame.setDeveloper(gameDev.getText());
            selectedGame.setYear(Integer.parseInt(gameYear.getText()));
            selectedGame.setCover(gameCover.getText());

            // Display save message
            System.out.println("Game " + selectedGame.getTitle() + " updated successfully!");
        }
    }

    // Returns the user to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
