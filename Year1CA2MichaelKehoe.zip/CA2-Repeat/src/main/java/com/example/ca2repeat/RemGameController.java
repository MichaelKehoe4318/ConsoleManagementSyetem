package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import java.io.IOException;

public class RemGameController {

    public ChoiceBox<Game> selectedDelGame;
    public ChoiceBox<Console> selectedConsole;

    public void delGame(ActionEvent actionEvent) {
        Game selectedGame = selectedDelGame.getValue();

        if (selectedGame != null) {
            Console selectedConsole = this.selectedConsole.getValue();

            if (selectedConsole != null) {
                FunkyList<Game> consoleGames = selectedConsole.getConsoleGames();
                if (consoleGames != null) {
                    consoleGames.remove(selectedGame);
                    System.out.println("Game '" + selectedGame.getTitle() + "' deleted");
                    selectedDelGame.getItems().remove(selectedGame);
                } else {
                    System.out.println("No games found");
                }
            } else {
                System.out.println("No console selected");
            }
        } else {
            System.out.println("No game selected");
        }
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
            selectedConsole.getItems().add(consoleNode.getContents());
            FunkyList<Game>.FunkyNode<Game> gameNode = consoleNode.getContents().getConsoleGames().head;
            while (gameNode != null) {
                selectedDelGame.getItems().add(gameNode.getContents());
                gameNode = gameNode.next;
            }
            consoleNode = consoleNode.next;
        }
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
