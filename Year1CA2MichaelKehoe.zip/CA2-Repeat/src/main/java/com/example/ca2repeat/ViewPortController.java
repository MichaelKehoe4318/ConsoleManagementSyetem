package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.io.IOException;

public class ViewPortController {
    public ListView viewPorts;
    public Button homeButton;

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }

    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> ctemp=Console.consoleList.head;
        while(ctemp!=null) {
            FunkyList<Port>.FunkyNode<Port> temp= Console.consolePorts.head;
            while(temp!=null) {
                viewPorts.getItems().add(temp.getContents());
                temp = temp.next;
            }
            ctemp=ctemp.next;
        }
    }
}
