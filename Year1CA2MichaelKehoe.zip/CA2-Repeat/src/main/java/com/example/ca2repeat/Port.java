package com.example.ca2repeat;

public class Port {
    //Fields
    String portName, portDev, portCover;
    int portRelease;

    //Getters

    public String getPortName() {
        return portName;
    }

    public String getPortDev() {
        return portDev;
    }

    public String getPortCover() {
        return portCover;
    }

    public int getPortRelease() {
        return portRelease;
    }

    public FunkyList<Port> getGamePorts() {Game temp = new Game("name", "desc", "flag", "picture",
            "cover", 1234);
        return temp.getGamePorts();
    }

    //Setters

    public void setPortName(String portName) {
        this.portName = portName;
    }

    public void setPortDev(String portDev) {
        this.portDev = portDev;
    }

    public void setPortCover(String portCover) {
        this.portCover = portCover;
    }

    public void setPortRelease(int portRelease) {
        this.portRelease = portRelease;
    }

    //portName, portedTo, portDev, portCover int portRelease;
    public Port(String name, String portDeveloper, String cover, int portRel){
        this.portName=name;
        portDev=portDeveloper;
        portCover=cover;
        portRelease=portRel;
    }

    public static Port getPortByName(String value) {
        FunkyList<Console>.FunkyNode<Console> ptemp = Console.consoleList.head;
        while (ptemp != null) {
            FunkyList<Game>.FunkyNode<Game> stemp = ptemp.getContents().consoleGames.head;
            while (stemp != null) {
                FunkyList<Port>.FunkyNode<Port> ctemp = stemp.getContents().gamePorts.head;
                while (ctemp != null && ctemp.getContents().getPortName() != value)
                    ctemp = ctemp.next;

                if (ctemp != null)
                    return ctemp.getContents();

                stemp = stemp.next;
            }

            FunkyList<Port>.FunkyNode<Port> pctemp = Console.consolePorts.head;

            ptemp = ptemp.next;
        }
        return null;
    }

    public String toString(){return "Port Title: "+portName+" Ported by: "+portDev+" Game cover: "+portCover+" Port released: "+portRelease;
    }
}
