package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import java.io.IOException;
import java.util.HashMap;

public class SearchSystemController {

    public TextField searchTarget;
    public ListView<String> searchResults;
    public ListView<String> detailsView;
    public Button searchButton;

    private static final HashMap<String, Console> consoleMap = new HashMap<>();
    private static final HashMap<String, Game> gameMap = new HashMap<>();
    private static final HashMap<String, Port> portMap = new HashMap<>();

    // To hold references to objects found in search
    private final HashMap<String, Object> searchObjectMap = new HashMap<>();

    public void initialize() {
        populateHashMaps();
        searchResults.setOnMouseClicked(this::handleListViewClick); // Add click handler
    }

    private void populateHashMaps() {
        consoleMap.clear();
        gameMap.clear();
        portMap.clear();
        searchObjectMap.clear(); // Clear object references

        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
            Console console = consoleNode.getContents();
            consoleMap.put(console.getConsole().toLowerCase(), console);

            FunkyList<Game>.FunkyNode<Game> gameNode = console.getConsoleGames().head;
            while (gameNode != null) {
                Game game = gameNode.getContents();
                gameMap.put(game.getTitle().toLowerCase(), game);

                FunkyList<Port>.FunkyNode<Port> portNode = game.getGamePorts().head;
                while (portNode != null) {
                    Port port = portNode.getContents();
                    portMap.put(port.getPortName().toLowerCase(), port);
                    portNode = portNode.next;
                }

                gameNode = gameNode.next;
            }

            consoleNode = consoleNode.next;
        }
    }

    public void SearchFunction(ActionEvent actionEvent) {
        String searchTerm = searchTarget.getText().toLowerCase();
        searchResults.getItems().clear();
        detailsView.getItems().clear(); // Clear previous details
        searchObjectMap.clear(); // Clear object references
        boolean matchFound = false;

        for (Console console : consoleMap.values()) {
            if (console.getConsole().toLowerCase().contains(searchTerm)) {
                String result = "Console Found: " + console.getConsole();
                searchResults.getItems().add(result);
                searchObjectMap.put(result, console);
                matchFound = true;
            }
        }

        for (Game game : gameMap.values()) {
            if (game.getTitle().toLowerCase().contains(searchTerm)) {
                String result = "Game Found: " + game.getTitle();
                searchResults.getItems().add(result);
                searchObjectMap.put(result, game);
                matchFound = true;
            }
        }

        for (Port port : portMap.values()) {
            if (port.getPortName().toLowerCase().contains(searchTerm)) {
                String result = "Port Found: " + port.getPortName();
                searchResults.getItems().add(result);
                searchObjectMap.put(result, port);
                matchFound = true;
            }
        }

        if (!matchFound) {
            searchResults.getItems().add("No match found for: " + searchTerm);
        }
    }

    private void handleListViewClick(MouseEvent event) {
        if (event.getClickCount() == 2) { // Double-click
            String selectedItem = searchResults.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                Object selectedObject = searchObjectMap.get(selectedItem);
                if (selectedObject != null) {
                    displayDetails(selectedObject);
                } else {
                    detailsView.getItems().add("No details available for: " + selectedItem);
                }
            }
        }
    }

    private void displayDetails(Object object) {
        detailsView.getItems().clear(); // Clear previous details
        String details;
        if (object instanceof Console) {
            details = "Console Details:\n" + object;
        } else if (object instanceof Game) {
            details = "Game Details:\n" + object;
        } else if (object instanceof Port) {
            details = "Port Details:\n" + object;
        } else {
            details = "Unknown object type";
        }

        // Display details in the ListView
        detailsView.getItems().add(details);
    }

    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
