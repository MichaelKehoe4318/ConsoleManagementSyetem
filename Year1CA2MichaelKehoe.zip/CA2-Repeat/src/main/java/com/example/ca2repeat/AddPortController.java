package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddPortController {

    // Fields
    public TextField portName;
    public TextField portDev;
    public TextField portCover;
    public TextField portYear;
    public ChoiceBox<String> selectedConsole;
    public ChoiceBox<String> selectedGame;

    // Creates a port in the console's game's list
    public void CreatePort(ActionEvent actionEvent) {
        try {
            int portYearInt = Integer.parseInt(portYear.getText());

            // Get the selected game
            Game selectedGameObj = Game.getGameByName(selectedGame.getValue());

            // Check if the port year is before the game's release year
            if (selectedGameObj != null && portYearInt >= selectedGameObj.getYear()) {
                Port port1 = new Port(portName.getText(), portDev.getText(), portCover.getText(), portYearInt);

                FunkyList<Console>.FunkyNode<Console> temp = Console.consoleList.head;
                while (temp != null && !temp.getContents().getConsole().equals(selectedConsole.getValue()))
                    temp = temp.next;

                if (temp != null) {
                    Console.consolePorts.addElement(port1);
                }
            } else {
                // Alert if the port year is before the game's release year
                showAlert("Error", "Port year cannot be before the game's release year");
            }
        } catch (NumberFormatException e) {
            // Alert if portYear is not an integer
            showAlert("Error", "Please enter a valid year.");
        }
    }

    //Fills selectedConsole ChoiceBox
    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> ptemp = Console.consoleList.head;
        while (ptemp != null) {
            selectedConsole.getItems().add(ptemp.getContents().getConsole());
            ptemp = ptemp.next;
        }
    }

    // Fills selectedGame when console is picked
    public void consoleSelected(ActionEvent actionEvent) {
        Console selectedConsoleObj = Console.getConsoleByName(selectedConsole.getValue());
        selectedGame.getItems().clear();
        if (selectedConsoleObj != null) {
            FunkyList<Game>.FunkyNode<Game> gameNode = selectedConsoleObj.consoleGames.head;
            while (gameNode != null) {
                selectedGame.getItems().add(gameNode.getContents().getTitle());
                gameNode = gameNode.next;
            }
        }
    }

    // Shows error alert
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Returns the user to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}
