package com.example.ca2repeat;

import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class EditConsoleController {

    // Fields for editing console details
    public ChoiceBox<String> consoleChoiceBox;
    public TextField consoleName;
    public TextField consoleManufacturer;
    public TextField consoleDesc;
    public TextField consoleMedia;
    public TextField consoleYear;
    public TextField consolePrice;
    public TextField consoleImage;

    // Fill ChoiceBox with Consoles
    public void initialize() {
        FunkyList<Console>.FunkyNode<Console> consoleNode = Console.consoleList.head;
        while (consoleNode != null) {
            consoleChoiceBox.getItems().add(consoleNode.getContents().getConsole());
            consoleNode = consoleNode.next;
        }
    }

    // Load console data into the fields
    public void loadConsoleData(ActionEvent actionEvent) {
        Console selectedConsole = Console.getConsoleByName(consoleChoiceBox.getValue());
        if (selectedConsole != null) {
            consoleName.setText(selectedConsole.getConsole());
            consoleManufacturer.setText(selectedConsole.getManufacturer());
            consoleDesc.setText(selectedConsole.getDescription());
            consoleMedia.setText(selectedConsole.getMedia());
            consoleYear.setText(String.valueOf(selectedConsole.getYear()));
            consolePrice.setText(String.valueOf(selectedConsole.getPrice()));
            consoleImage.setText(selectedConsole.getImage());
        }
    }

    // Save changes made to console
    public void saveConsoleChanges(ActionEvent actionEvent) {
        Console selectedConsole = Console.getConsoleByName(consoleChoiceBox.getValue());
        if (selectedConsole != null) {
            // Update console with inputs
            selectedConsole.setName(consoleName.getText());
            selectedConsole.setManufacturer(consoleManufacturer.getText());
            selectedConsole.setDescription(consoleDesc.getText());
            selectedConsole.setMedia(consoleMedia.getText());
            selectedConsole.setYear(Integer.parseInt(consoleYear.getText()));
            selectedConsole.setPrice(Integer.parseInt(consolePrice.getText()));
            selectedConsole.setImage(consoleImage.getText());

            //Display save message
            System.out.println("Console " + selectedConsole.getConsole() + " updated successfully!");
        }
    }

    // Returns the user to the main menu
    public void goHome(ActionEvent actionEvent) throws IOException {
        HelloApplication.changeScene("MainMenuController.fxml");
    }
}

