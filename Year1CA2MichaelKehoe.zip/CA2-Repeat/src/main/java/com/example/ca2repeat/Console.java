package com.example.ca2repeat;

public class Console {

    //Fields
    String name,manufacturer,description,media,image;
    int year,price;

    public static Console head;

    public FunkyList<Game> consoleGames = new FunkyList<>();
    public static FunkyList<Port> consolePorts = new FunkyList<>();

    public static FunkyList<Console> consoleList = new FunkyList<>();

    public Console(String name,String manu, String desc, String medType, String imgURL, int cost, int relYear){
        this.name=name;
        manufacturer=manu;
        description=desc;
        media=medType;
        price=cost;
        year=relYear;
        image=imgURL;
    }

    //Getters
    public String getConsole(){return name;}

    public String getManufacturer(){return manufacturer;}

    public String getDescription(){return description;}

    public String getMedia(){return media;}

    public int getPrice(){return price;}

    public int getYear(){return year;}

    public String getImage(){return image;}

    public FunkyList<Game> getConsoleGames() {
        return consoleGames;
    }
    public FunkyList<Port> getConsolePorts(){return consolePorts;}

    //Setters
    public void setName(String name){this.name=name;}

    public void setManufacturer(String manufacturer){this.manufacturer=manufacturer;}

    public void setDescription(String description){this.description=description;}

    public void setMedia(String media){this.media=media;}

    public void setPrice(int price){this.price=price;}

    public void setYear(int year){this.year=year;}

    public void setImage(String image ){this.image=image;}

    //adds console to list of consoles
    public void addConsole(Console con) {Console.consoleList.addElement(con);
    }

    public static Console getConsoleByName(String value) {
        FunkyList<Console>.FunkyNode<Console> temp = consoleList.head;
        while (temp != null) {
            if (temp.getContents().getConsole().equals(value)) {
                return temp.getContents();
            }
            temp = temp.next;
        }
        return null;
    }

//ToString String name,String manu, String desc, String medType, int cost, int relYear, String imgURL
    public String toString(){return "Console name: "+name+" Description: "+description+" Media Type: "+media+" Launch year: "+year+" Initial Cost: "+price+" Image: "+image;
    }
}

