module com.example.ca2repeat {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ca2repeat to javafx.fxml;
    exports com.example.ca2repeat;
}